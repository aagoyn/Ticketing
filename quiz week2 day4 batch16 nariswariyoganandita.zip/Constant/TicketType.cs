﻿namespace Ticketing.Constant;

public enum TicketType
{
    Bus,
    Kereta,
    Pesawat
}
