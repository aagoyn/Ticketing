﻿namespace Ticketing;

using Ticketing.View;
class Program
{
    public static void Main()
    {
        MainView mv = new MainView();
        mv.ShowMainMenu();
    }
}

